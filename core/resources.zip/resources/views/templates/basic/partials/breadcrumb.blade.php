<div class="privacy-banner section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2 class="section__title m-0 text-center">{{ __($pageTitle) }}</h2>
            </div>
        </div>
    </div>
</div>
